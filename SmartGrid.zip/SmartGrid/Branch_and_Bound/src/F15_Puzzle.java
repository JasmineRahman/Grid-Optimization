class Puzzle {
    char[] path;
    int m, n;
    int[][] matrix;

    Puzzle(int m, int n) {
        this.m = m;
        this.n = n;
        this.matrix = new int[m][n];
        this.path = new char[m * n];
    }

    public int LowerBound(int[][] matrix) {
        int k = 1;
        int count = 0;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (k != m * n && matrix[i][j] != k) {
                    count += 1;
                }
                k += 1;
            }
        }
        return count;
    }

    public void Calculate_puzzle(int[][] mat, char c, int m, int n, int i) {
        matrix = mat;
        int lb1, lb2, lb3, lb4;
        int min = Integer.MAX_VALUE;

        if (c != 'u' && m > 0) {
            int s = matrix[m - 1][n];
            matrix[m - 1][n] = matrix[m][n];
            matrix[m][n] = s;
            lb1 = LowerBound(matrix);
            if (lb1 < min) {
                min = lb1;
                c = 'd';
            }
            // Undo the move
            s = matrix[m - 1][n];
            matrix[m - 1][n] = matrix[m][n];
            matrix[m][n] = s;
        }
        if (c != 'd' && m < this.m - 1) {
            int s = matrix[m + 1][n];
            matrix[m + 1][n] = matrix[m][n];
            matrix[m][n] = s;
            lb2 = LowerBound(matrix);
            if (lb2 < min) {
                min = lb2;
                c = 'u';
            }
            // Undo the move
            s = matrix[m + 1][n];
            matrix[m + 1][n] = matrix[m][n];
            matrix[m][n] = s;
        }
        if (c != 'r' && n < this.n - 1) {
            int s = matrix[m][n + 1];
            matrix[m][n + 1] = matrix[m][n];
            matrix[m][n] = s;
            lb3 = LowerBound(matrix);
            if (lb3 < min) {
                min = lb3;
                c = 'l';
            }
            // Undo the move
            s = matrix[m][n + 1];
            matrix[m][n + 1] = matrix[m][n];
            matrix[m][n] = s;
        }
        if (c != 'l' && n > 0) {
            int s = matrix[m][n - 1];
            matrix[m][n - 1] = matrix[m][n];
            matrix[m][n] = s;
            lb4 = LowerBound(matrix);
            if (lb4 < min) {
                min = lb4;
                c = 'r';
            }
            // Undo the move
            s = matrix[m][n - 1];
            matrix[m][n - 1] = matrix[m][n];
            matrix[m][n] = s;
        }
        path[i] = c;
        if (min == 0) {
            return;
        }
        Calculate_puzzle(matrix, c, m, n, i + 1);
    }
}

public class F15_Puzzle {
    public static void main(String args[]) {
        Puzzle matrix =                  new Puzzle(4, 4);
        int[][] mat = {{1, 2, 3, 4},
                {5, 6, 0, 8},
                {9, 10, 7, 11},
                {13, 14, 15, 12}};
        matrix.Calculate_puzzle(mat, 'e', 1, 1, 0); // Changed initial position to (1, 1)
        for (int j = 0; j < matrix.path.length; j++) {
            if (matrix.path[j] != '\u0000') {
                System.out.print(matrix.path[j] + " ");
            }
        }
    }
}
