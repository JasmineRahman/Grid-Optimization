
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.Hashtable;

public class mee {
    private Dictionary<String, Integer> placedict = new Hashtable<>();

    public static void main(String[] args) {
        mee main = new mee();
        main.placedict.put("Key1", 1);
        main.placedict.put("Key2", 2);
        main.placedict.put("Key3", 3);

        String keyToCheck = "Key2";
        boolean keyExists = main.containsKey(keyToCheck);
        System.out.println("Key " + keyToCheck + " exists in placedict: " + keyExists);
    }

    public boolean containsKey(String key) {
        Enumeration<String> keys = placedict.keys();
        while (keys.hasMoreElements()) {
            if (key.equals(keys.nextElement())) {
                return true;
            }
        }
        return false;
    }
}
